#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void tic_tac();
bool winner(char board[9]);
bool tie (char board[9]);
void printBoard(char board[9]);
